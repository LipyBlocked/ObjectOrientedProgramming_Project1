package Gosssip;

import dataStructures.*;

public class PersonClass extends AbstractPerson {

    private static final String TYPE = "PERSON";

    protected Array<Gossip> gossips;
    protected boolean isWilling;
    private String type;

    public PersonClass(String name) {
        super(name, TYPE);
        gossips = new ArrayClass<Gossip>();
    }

    @Override
    public boolean hasGossipsToShare() {
        return gossips.size() > 0;
    }

    @Override
    public String getType() {
        return type;
    }


    @Override
    public Iterator<Gossip> personGossips() {
        return gossips.iterator();
    }


    @Override
    public void addGossip(Gossip g) {
        gossips.insertLast(g);
    }

    @Override
    public int getNumberOfGossips() {
        return 0;
    }

    @Override
    public boolean hasGossip(Gossip gossip) {
        return gossips.searchForward(gossip);
    }

    @Override
    public void shareGossip(Array<Person> members) {
        // TODO Auto-generated method stub
    }

	@Override
	public Iterator<Gossip> gossipsToShare() {
		// TODO Auto-generated method stub
		return null;
	}


}
