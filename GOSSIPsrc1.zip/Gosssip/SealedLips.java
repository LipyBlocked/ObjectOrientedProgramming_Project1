package Gosssip;

public interface SealedLips extends Person {

	/**
	 * Sees if a sealed lips person is willing to share a gossip
	 * @return <code>true</code> if the person is willing to share
	 * 		   <code>false</code> otherwise
	 */
	boolean isWillingToShare();

}
