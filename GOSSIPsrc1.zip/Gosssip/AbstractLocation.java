package Gosssip;

public abstract class AbstractLocation implements Location {

    /**
     * The name of the location
     */
    protected String name;

    /**
     * Constructor that initializes the variable
     * @param landmarkName the name of the location
     */
    public AbstractLocation(String landmarkName) {
        name = landmarkName;
    }

    /**
     * Sees if the location is
     * @return <code>true</code>
     */
    public boolean isHomeType() {
        return name.equals(null);
    }

    /**
     * Returns the name of the location
     * @return the name of the location
     */
    public String getName() {
        return name;
    }

    /**
     * Compares <code>this</code> location to this <code>obj</code> location
     * @param obj the location being compared to
     * @return <code>true</code> if they're equal
     *         <code>false</code> otherwise
     */
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof AbstractLocation)) {
            return false;
        }
        AbstractLocation other = (AbstractLocation) obj;
        if (name == null) {
            if (other.name != null) {
                return false;
            }
        } else if (!name.equals(other.name)) {
            return false;
        }
        return true;
    }


}
