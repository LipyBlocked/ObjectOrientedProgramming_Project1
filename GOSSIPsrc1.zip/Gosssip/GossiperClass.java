package Gosssip;

import dataStructures.*;

public class GossiperClass extends AbstractPerson implements Gossiper {

	private static final String TYPE = "gossiper";
	
	private Array<Gossip> gossips;
	private Array<Gossip> gossipsToShare;
	
	public GossiperClass(String name) {
		super(name,TYPE);
		gossips = new ArrayClass<Gossip>();
		gossipsToShare = new ArrayClass<Gossip>(3);
	}

	@Override
	public int getNumberOfGossips() {
		return gossips.size();
	}

	@Override
	public Iterator<Gossip> personGossips() {
		return gossips.iterator();
	}

	@Override
	public boolean hasGossipsToShare() {
		return gossips.size()>0;
	}

	@Override
	public void addGossip(Gossip g) {
		if(!gossips.searchForward(g)){
			gossips.insertLast(g);
		}
	}

	@Override
	public boolean hasGossip(Gossip gossip) {
		return gossips.searchForward(gossip);
	}

	@Override
	public void shareGossip(Array<Person> members) {
		Array<Gossip> auxGossips = new ArrayClass<Gossip>();
		int i=0; 
		while(i<3&&gossips.get(0)!=null) {
			auxGossips.insertLast(gossips.get(0));
			gossips.insertLast(gossips.get(0));
			gossips.removeAt(0);
			i++;
		}
		gossipsToShare = auxGossips;
		for(int g=0;g<gossipsToShare.size();g++) {
			for(int m=0;m<members.size();m++) {
				members.get(m).addGossip(gossipsToShare.get(g));
			}
		}
	}

	@Override
	public Iterator<Gossip> gossipsToShare() {
		return gossipsToShare.iterator();
	}
	
	
	

	
}
