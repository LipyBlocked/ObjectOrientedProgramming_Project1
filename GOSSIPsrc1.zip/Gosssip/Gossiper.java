package Gosssip;

public interface Gossiper extends Person {

}
