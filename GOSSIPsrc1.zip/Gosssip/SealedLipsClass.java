package Gosssip;

import dataStructures.*;

public class SealedLipsClass extends AbstractPerson implements SealedLips {
	
	private static final String TYPE = "sealed";
	
	private Array<Gossip> gossips;
	private Array<Gossip> gossipsToShare;
	int currentSharebleGossip;

	public SealedLipsClass(String name) {
		super(name,TYPE);
		gossips = new ArrayClass<Gossip>();
		gossipsToShare = new ArrayClass<Gossip>(1);
		currentSharebleGossip = 0;
	}
	

	@Override
	public int getNumberOfGossips() {
		return gossips.size();
	}


	@Override
	public boolean hasGossipsToShare() {
		return gossips.size()>0;
	}


	@Override
	public boolean isWillingToShare() {
		int i = 0;
		while(i<gossips.size()) {	
			Iterator <Person> it = gossips.get(i).targets();
			while(it.hasNext()) {
				Person p = it.next();
				if(p.getName().equals(this.getName())) {
					return true;
				}
			}
			i++;
		}
		return false;
	}


	@Override
	public Iterator<Gossip> personGossips() {
		return gossips.iterator();
	}


	@Override
	public void addGossip(Gossip g) {
		if(!gossips.searchForward(g)){
			gossips.insertLast(g);
		} 	
	}


	@Override
	public boolean hasGossip(Gossip gossip) {
		return gossips.searchForward(gossip);
	}


	@Override
	public void shareGossip(Array<Person> members) {
		Array<Gossip> auxGossips = new ArrayClass<Gossip>();
		auxGossips.insertLast(gossips.get(sharebleGossip()));
		gossips.insertLast(gossips.get(sharebleGossip()));
		gossips.removeAt(sharebleGossip());
		gossipsToShare = auxGossips;
		
		for(int m=0;m<members.size();m++) {
			members.get(m).addGossip(gossipsToShare.get(sharebleGossip()));
		}
	}
	
	private int sharebleGossip() {
		int i =0;
		while(i<gossips.size()) {
			if(gossips.get(i).hasTarget(name)) {
				currentSharebleGossip = i;
				return currentSharebleGossip;
			}
			i++;
		}
		return currentSharebleGossip;
	}

	@Override
	public Iterator<Gossip> gossipsToShare() {
		return gossipsToShare.iterator();
	}
	

}
