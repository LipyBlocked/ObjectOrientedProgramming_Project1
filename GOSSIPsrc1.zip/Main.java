import java.util.Scanner;


import Gosssip.*;
import dataStructures.*;

/**
 * Main class for a gossip tracker application
 *
 * @author Lipy Cardoso - 63542
 * @author Pâmela Cuna - 63560
 */

public class Main {


    /**
     * Constants used in the program.
     */
    public static final String HOME = "home";

    /**
     * Constants that define the commands
     */
    private static final String EXIT = "exit";
    private static final String HELP = "help";
    private static final String LANDMARK = "landmark";
    private static final String LANDMARKS = "landmarks";
    private static final String FORGETFUL = "forgetful";
    private static final String GOSSIPER = "gossiper";
    private static final String SEALED = "sealed";
    private static final String PEOPLE = "people";
    private static final String GO = "go";
    private static final String JOIN = "join";
    private static final String GROUPS = "groups";
    private static final String ISOLATE = "isolate";
    private static final String START = "start";
    private static final String GOSSIP = "gossip";
    private static final String SECRETS = "secrets";
    private static final String INFOTAINMENT = "infotainment";
    private static final String HOTTEST = "hottest";

    /**
     * Feedback given by the program.
     */
    private static final String EXIT_MESSAGE = "Bye!";

    /**
     * Main program. Invokes the command interpreter.
     *
     * @param args - arguments for the execution of the program.
     */
    public static void main(String[] args) {
        Main.commands();
    }

    /**
     * Command's interpreter.
     */
    private static void commands() {
        Community cm = new CommunityClass();
        Scanner input = new Scanner(System.in);
        String command;

        do {
            command = getCommand(input);
            switch (command) {
                case EXIT -> processExit(input, cm);
                case HELP -> processHelp(input, cm);
                case LANDMARK -> processLandmark(input, cm);
                case LANDMARKS -> processLandmarks(input, cm);
                case FORGETFUL -> processForgetful(input, cm);
                case GOSSIPER -> processGossiper(input, cm);
                case SEALED -> processSealed(input, cm);
                case PEOPLE -> processPeople(input, cm);
                case GO -> processGo(input, cm);
                case JOIN -> processJoin(input, cm);
                case GROUPS -> processGroups(input, cm);
                case ISOLATE -> processIsolate(input, cm);
                case START -> processStart(input, cm);
                case GOSSIP -> processGossip(input, cm);
                case SECRETS -> processSecrets(input, cm);
                case INFOTAINMENT -> processInfotainment(input, cm);
                case HOTTEST -> processHottest(input, cm);
                default -> System.out.println("Unknown command. Type help to see available commands.");

            }
        } while (!command.equals(EXIT));
        input.close();
    }

    /**
     * Reads the command from the user and checks if written correctly.
     *
     * @param input - to read the user input.
     * @return - the command or an error message.
     */
    private static String getCommand(Scanner input) {
        try {
            String command = input.next().toLowerCase();
            return command;
        } catch (IllegalArgumentException e) {
            return "Unknown command. Type help to see available commands.";
        }
    }

    /**
     * Lists the most shared gossip.
     *
     * @param input - to read the user input.
     * @param cm    - the Community to which the most shared gossip will be listed.
     */
    private static void processHottest(Scanner input, Community cm) {

    }

    /**
     * Lists the gossips a particular person is aware off.
     *
     * @param input - to read the user input.
     * @param cm    - the Community to which the gossip a particular person is aware off will be listed.
     */
    private static void processInfotainment(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();

        if (!cm.hasPerson(person_name)) {
            System.out.printf("%s does not exist!\n", person_name);
        } else if (!cm.hasGossipsToShare(person_name)) {
            System.out.printf("%s knows nothing!\n", person_name);
        } else {
            System.out.printf("%s knows things:\n", person_name);
            Iterator<Gossip> it = cm.personGossips(person_name);
            while (it.hasNext()) {
                Gossip g = it.next();
                System.out.println(g.getGossipDescription());
            }
        }
    }

    /**
     * Lists the gossip about a particular person.
     *
     * @param input - to read the user input.
     * @param cm    - the Community to which the gossip about a particular person will be listed.
     */
    private static void processSecrets(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();

        if (!cm.hasPerson(person_name)) {
            System.out.printf("%s does not exist!\n", person_name);
        } else if (!cm.hasSecrets(person_name)) {
            System.out.printf("%s lives a very boring life!\n", person_name);
        } else {
            Iterator<Gossip> it = cm.gossipsAbout(person_name);
            System.out.printf("Here is what we know about %s:\n", person_name);
            while (it.hasNext()) {
                Gossip g = it.next();
                System.out.printf("%d %s\n", cm.peopleAwareOfGossip(g), g.getGossipDescription());
            }
        }
    }

    /**
     * Shares a gossip within the current group in the current landmark.
     *
     * @param input - to read the user input.
     * @param cm    - the Community to which a gossip within the current group will be shared.
     */
    private static void processGossip(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();

        if (!cm.hasPerson(person_name)) {
            System.out.printf("%s does not exist!\n", person_name);
        } else if (cm.isIsolated(person_name) || cm.getPersonLocation(person_name).equals(HOME)) {
            System.out.printf("%s has nobody to gossip with right now!\n", person_name);
        } else if (!cm.hasGossipsToShare(person_name)) {
            System.out.printf("%s knows nothing!\n", person_name);
        } else if (!cm.isWillingToShare(person_name)) {
            System.out.printf("%s does not wish to gossip right now!\n", person_name);
        } else {
            cm.gossip(person_name);
            String members = "";
            Iterator<Person> it = cm.personGroupMembers(person_name);
            boolean isFirstPerson = true;
            boolean hasSinglePerson = true;
            while (it.hasNext()) {
                Person p = it.next();
                if (!p.getName().equals(person_name)) {
                    if (isFirstPerson) {
                        members = p.getName();
                        isFirstPerson = false;
                    } else {
                        members = members + ", " + p.getName();
                        hasSinglePerson = false;
                    }
                }
                
            }
            if(hasSinglePerson){members = members + ",";}
            System.out.printf("%s shared with %s some hot news!\n", person_name, members);
            Iterator<Gossip> gIT = cm.gossipsToShare(person_name);
            while (gIT.hasNext()) {
                Gossip g = gIT.next();
                System.out.println(g.getGossipDescription());
            }
        }
    }

    /**
     * Starts a new gossip.
     *
     * @param input - to read the user input
     * @param cm    - the Community to which the new gossip will be started.
     */
    private static void processStart(Scanner input, Community cm) {
        String gossip_creator_name = input.nextLine().trim();
        int gossip_target_nr = input.nextInt();
        input.nextLine();
        Array<String> targetNames = new ArrayClass<String>();
        int inserted_targets = 0;
        while (inserted_targets < gossip_target_nr) {
            String aux_target_name = input.nextLine().trim();
            targetNames.insertLast(aux_target_name);
            inserted_targets++;
        }


        String gossip_description = input.nextLine().trim();
        if (!cm.hasPerson(gossip_creator_name)) {
            System.out.printf("%s does not exist!\n", gossip_creator_name);
        } else if (gossip_target_nr <= 0) {
            System.out.printf("Invalid number %d of gossip targets!\n", gossip_target_nr);
        } else {
            if (!(cm.getNonExistentPerson(targetNames) == null)) {
                System.out.printf("%s does not exist!\n", cm.getNonExistentPerson(targetNames));
            } else {
                if (cm.hasDuplicateGossip(gossip_creator_name, targetNames, gossip_description)) {
                    System.out.println("Duplicate gossip!");
                } else {
                    String targets = "";
                    cm.startGossip(gossip_creator_name, targetNames, gossip_description);
                    Iterator<Person> it = cm.gossipTargets(gossip_creator_name, targetNames, gossip_description);
                    boolean isFirstPerson = true;
                    while (it.hasNext()) {
                        Person p = it.next();
                        if (isFirstPerson) {
                            targets = p.getName();
                            isFirstPerson = false;
                        } else {
                            targets = targets + ", " + p.getName();
                        }
                    }
                    System.out.printf("Have you heard about %s? %s\n", targets, gossip_description);
                }
            }
        }


    }

    /**
     * Makes a person leave the current group, but not the landmark the person is currently on.
     *
     * @param input - to read the user input
     * @param cm    - the Community to which a person will leave the current group.
     */
    private static void processIsolate(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();
        if (!cm.hasPerson(person_name)) {
            System.out.printf("%s does not exist!\n", person_name);
        } else if (cm.getPersonLocation(person_name).equals(HOME)) {
            System.out.printf("%s is at home!\n", person_name);
        } else if (cm.isIsolated(person_name)) {
            System.out.printf("%s is already alone!\n", person_name);
        } else {
            cm.isolate(person_name);
            System.out.printf("%s is now alone at %s.\n", person_name, cm.getPersonLocation(person_name));
        }

    }

    /**
     * Lists the groups composition in a landmark.
     *
     * @param input - the user input.
     * @param cm    - the Community to which the groups composition in a landmark will be listed.
     */
    private static void processGroups(Scanner input, Community cm) {
        String landmark_name = input.nextLine().trim();
        if (landmark_name.equals(HOME)) {
            System.out.println("You must understand we have no surveillance tech at home! Privacy is our top concern!");
        } else if (!cm.hasLandMark(landmark_name, 0)) {
            System.out.printf("%s does not exist!\n", landmark_name);
        } else if (cm.landmarkIsEmpty(landmark_name)) {
            System.out.printf("Nobody is at %s!\n", landmark_name);
        } else {
            System.out.printf("%d groups at %s:\n", cm.getNrOfGroups(landmark_name), landmark_name);
            Iterator<Group> gIT = cm.groups(landmark_name);
            while (gIT.hasNext()) {
                Group g = gIT.next();
                String members = "";
                Iterator<Person> it = g.listGroupMembers();
                boolean isFirstPerson = true;
                while (it.hasNext()) {
                    Person p = it.next();
                    if (isFirstPerson) {
                        members = members + p.getName();
                        isFirstPerson = false;
                    } else {
                        members = members + ", " + p.getName();
                    }
                }
                System.out.println(members);
            }
        }
    }

    /**
     * Joins a person to a group.
     *
     * @param input - the user input
     * @param cm    - the Community to which a person will be joined to a group.
     */
    private static void processJoin(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();
        String other_person_name = input.nextLine().trim();
        if (person_name.equals(other_person_name)) {
            System.out.printf("%s needs a company from someone else!\n", person_name);
        } else if (!cm.hasPerson(person_name)) {
            System.out.printf("%s does not exist!\n", person_name);
        } else if (!cm.hasPerson(other_person_name)) {
            System.out.printf("%s does not exist!\n", other_person_name);
        } else if (cm.getPersonLocation(person_name).equals(HOME)) {
            System.out.printf("%s is at home!\n", person_name);
        } else if (!cm.getPersonLocation(other_person_name).equals(cm.getPersonLocation(person_name))) {
            System.out.printf("%s is not in %s!\n", other_person_name, cm.getPersonLocation(person_name));
        } else if (cm.areInSameGroup(person_name, other_person_name)) {
            System.out.printf("%s and %s are already in the same group!\n", person_name, other_person_name);
        } else {
            String members = "";
            Iterator<Person> it = cm.personGroupMembers(other_person_name);
            while (it.hasNext()) {
                Person p = it.next();
                members = members + p.getName() + ", ";
            }
            cm.joinGroup(person_name, other_person_name);
            System.out.printf("%s joined %sat the %s.\n", person_name, members, cm.getPersonLocation(person_name));
        }
    }

    /**
     * Moves a person to a landmark, or home.
     *
     * @param input - the user input.
     * @param cm    - the Community to which a person will be moved.
     */
    private static void processGo(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();
        String destination = input.nextLine().trim();
        if (!cm.hasPerson(person_name)) {
            System.out.printf("%s does not exist!\n", person_name);
        } else if (!cm.hasLandMark(destination, 0)) {
            System.out.printf("Unknown place %s!\n", destination);
        } else if (cm.getPersonLocation(person_name).equals(destination)) {
            System.out.printf("What do you mean go to %s? %s is already there!\n", destination, person_name);
        } else if (cm.landmarkIsFull(destination)) {
            System.out.printf("%s is too crowded! %s went home.\n", destination, person_name);
            cm.goHome(person_name);
        } else {
            cm.goTo(person_name, destination);
            System.out.printf("%s is now at %s.\n", person_name, destination);
        }
    }

    /**
     * Lists all the persons in the community.
     *
     * @param input - the user input.
     * @param cm    - the Community to which all the persons will be listed.
     */
    private static void processPeople(Scanner input, Community cm) {
        if (cm.hasNoPerson()) {
            System.out.println("This community does not have any people yet!");
        } else {
            Iterator<Person> it = cm.listPeople();
            while (it.hasNext()) {
                Person p = it.next();
                System.out.printf("%s at %s knows %d gossips.\n", p.getName(), p.getCurrentLocation(), p.getNumberOfGossips());
            }
        }
    }

    /**
     * Adds a sealed lips person to the community
     *
     * @param input - the user input.
     * @param cm    - the Community to which a sealed lips person will be added.
     */
    private static void processSealed(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();
        if (cm.hasPerson(person_name)) {
            System.out.printf("%s already exists!\n", person_name);
        } else {
            cm.registSealedPerson(person_name);
            System.out.printf("%s lips are sealed.\n", person_name);
        }
    }

    /**
     * Adds a gossiper person to the community.
     *
     * @param input - the user input.
     * @param cm    - the Community to which a gossiper person will be added.
     */
    private static void processGossiper(Scanner input, Community cm) {
        String person_name = input.nextLine().trim();
        if (cm.hasPerson(person_name)) {
            System.out.printf("%s already exists!\n", person_name);
        } else {
            cm.registGossiperPerson(person_name);
            System.out.printf("%s is a gossiper.\n", person_name);
        }
    }

    /**
     * Adds a forgetful person to the community.
     *
     * @param input - the user input.
     * @param cm    - the Community to which a forgetful person will be added.
     */
    private static void processForgetful(Scanner input, Community cm) {
        int gossip_capacity = input.nextInt();
        String person_name = input.nextLine().trim();
        if (gossip_capacity <= 0) {
            System.out.printf("Invalid gossips capacity %d!\n", gossip_capacity);
        } else if (cm.hasPerson(person_name)) {
            System.out.printf("%s already exists!\n", person_name);
        } else {
            cm.registForgetfulPerson(person_name, gossip_capacity);
            System.out.printf("%s can only remember up to %d gossips.\n", person_name, gossip_capacity);
        }
    }

    /**
     * Displays the list of landmarks in the community.
     *
     * @param input - the user input.
     * @param cm    - the Community to which the list of landmarks will be displayed.
     */
    private static void processLandmarks(Scanner input, Community cm) {
        if (cm.hasNoLandMarks()) {
            System.out.println("This community does not have any landmarks yet!");
        } else {
            Iterator<Landmark> it = cm.listLandmarks();
            while (it.hasNext()) {
                Landmark lm = it.next();
                System.out.printf("%s: %d %d.\n", lm.getName(), lm.getCapacity(), lm.getCurrentOccupation());
            }
        }

    }

    /**
     * Adds a new landmark to the community.
     *
     * @param input - the user input.
     * @param cm    - the Community to which a new landmark will be added.
     */
    private static void processLandmark(Scanner input, Community cm) {
        int landmark_capacity = input.nextInt();
        String landmark_name = input.nextLine().trim();
        if (landmark_capacity <= 0) {
            System.out.printf("Invalid landmark capacity %d!\n", landmark_capacity);
        } else if (landmark_name.equals(HOME)) {
            System.out.println("Cannot create a landmark called home. You know, there is no place like home!");
        } else if (cm.hasLandMark(landmark_name, landmark_capacity)) {
            System.out.printf("Landmark %s already exists!\n", landmark_name);
        } else {
            cm.registLandmark(landmark_name, landmark_capacity);
            System.out.printf("%s added.\n", landmark_name);
        }
    }

    /**
     * Shows the available commands.
     *
     * @param input - to read the user input.
     * @param cm    - the Community to which the available commands will be shown.
     */
    private static void processHelp(Scanner input, Community cm) {
        for (Command c : Command.values()) {
            System.out.println(c.getCmdDescription());
        }
    }

    /**
     * Terminates the execution of the program.
     *
     * @param input - to read the user input.
     * @param cm    - the Community to which the program will be terminated.
     */
    private static void processExit(Scanner input, Community cm) {
        System.out.println(EXIT_MESSAGE);
    }

    /**
     * The class that contains the set of fixed constants that represent the commands.
     */
    private enum Command {
        LANDMARK("landmark - adds a new landmark to the community"),
        LANDMARKS("landmarks - displays the list of landmarks in the community"),
        FORGETFUL("forgetful - adds a forgetful person to the community"),
        GOSSIPER("gossiper - adds a gossiper person to the community"),
        SEALED("sealed - adds a sealed lips person to the community"),
        PEOPLE("people - lists all the persons in the community"),
        GO("go - moves a person to a landmark, or home"),
        JOIN("join - joins a person to a group"),
        GROUPS("groups - lists the groups composition in a landmark"),
        ISOLATE("isolate - makes a person leave the current group, but not the landmark the person is currently on"),
        START("start - starts a new gossip"),
        GOSSIP("gossip - share a gossip within the current group in the current landmark"),
        SECRETS("secrets - lists the gossip about a particular person"),
        INFOTAINMENT("infotainment - lists the gossips a particular person is aware of"),
        HOTTEST("hottest - lists the most shared gossip"),
        HELP("help - shows the available commands"),
        EXIT("exit - terminates the execution of the program");

        /**
         * Variable that gets the description of a command
         */
        private final String cmdDescription;

        /**
         * Initializes the variable cmdDescription
         *
         * @param cmdDescription - receives the cmdDescription given by the user.
         */
        private Command(String cmdDescription) {
            this.cmdDescription = cmdDescription;
        }

        /**
         * Gets the command description of a command.
         *
         * @return - returns the cmdDescription of the command given by the user.
         */
        public String getCmdDescription() {
            return cmdDescription;
        }
    }

}