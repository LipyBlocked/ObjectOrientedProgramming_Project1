package Gosssip;

import dataStructures.Array;
import dataStructures.Iterator;

public interface Community {

    /**
     * Sees if a community has the landmark <code>landmark_name</code>
     * @param landmark_name the name of the landmark
     * @param landmark_size the size of the landmark
     * @return <code>true</code> if a landmark with such name exists
     * 	 	   <code>false</code> otherwise
     */
    boolean hasLandMark(String landmark_name, int landmark_size);


    /**
     * Sees if a community doesn't have any person
     * @return <code>true</code> if the community doesn't have any person
     *     	   <code>false</code> otherwise
     */
    boolean hasNoPerson();

    /**
     * Iterator over a collection of landmark
     * @return iterator over landmarks
     */
    Iterator<Landmark> landmarks();

    /**
     * Iterator over a collection of person
     * @return iterator over people
     */
    Iterator<Person> people();

    /**
     * Sees if the community has a person with <code>name</code>
     * @param name the name of the person
     * @return <code>true</code> if the community has the person with <code>name</code>
     *       	<code>false</code> otherwise
     */
    boolean hasPerson(String name);

    /**
     * Registers a landmark with <code>landmark_name</code> and <code>landmark_capacity</code>
     * @param landmark_name the name of the landmark
     * @param landmark_capacity the capacity of the landmark
     */
    void registlandmark(String landmark_name, int landmark_capacity);

    /**
     * Adds a forgetful person to the community with <code>person_name</code> and <code>gossip_capacity</code>
     * @param person_name the name of the person
     * @param gossip_capacity the capacity of the gossip
     */
    void addForgetfulPerson(String person_name, int gossip_capacity);

    /**
     * Adds a gossiper person to the community with <code>person_name</code>
     * @param person_name the name of the person
     */
    void addGossiperPerson(String person_name);

    /**
     * Adds a sealed person to the community with <code>person_name</code>
     * @param person_name the name of the person
     */
    void addSealedPerson(String person_name);

    /**
     * Returns the location of <code>person_name</code>
     * @param person_name the name of the person
     * @return the location of the person
     */
    String getPersonLocation(String person_name);

    /**
     * Sees if the landmark <code>destination</code> is full
     * @param destination the landmark name
     * @return <code>true</code> if the landmark is full
     *        	<code>false</code> otherwise
     */
    boolean landmarkIsFull(String destination);

    /**
     * Sends <code>person_name</code> to <code>destination</code>
     * @param person_name the name of the person
     * @param destination the name of the destination
     */
    void goTo(String person_name, String destination);

    /**
     * Joins <code>person_name</code> to the group of <code>other_person_name</code>
     * @param person_name the name of the person being added
     * @param other_person_name the name of the person that is already in the group
     */
    void joinGroup(String person_name, String other_person_name);

    /**
     * Iterator over a collection of Person
     * @param person_name the name of one of the members of group
     * @return iterator over person group members
     */
    Iterator<Person> personGroupMembers(String person_name);

    /**
     * Sees if a landmark is empty
     * @param landmark_name the name of the landmark
     * @return <code>true</code> if the <code>landmark_name</code> is empty
     *         <code>false</code> otherwise
     */
    boolean landmarkIsEmpty(String landmark_name);

    /**
     * Returns the capacity of the landmark
     * @param landmark_name the name of the landmark
     * @return the capacity of the landmark
     */
    int getLandmarkCapacity(String landmark_name);

    /**
     * Iterator over a collection of Group
     * @param landmark_name the name of the landmark
     * @return iterator over groups
     */
    Iterator<Group> groups(String landmark_name);

    /**
     * Sees if two people are in the same group
     * @param person_name the name of one person
     * @param other_person_name the name of the other person
     * @return <code>true</code> if the people are in the same group
     *         <code>false</code> otherwise
     */
    boolean areInSameGroup(String person_name, String other_person_name);

    /**
     * Returns the number of groups in a landmark
     * @param landmark_name the name of the landmark
     * @return the number of groups in a landmark
     */
    int getNrOfGroups(String landmark_name);

    /**
     * Sees if a <code>person_name</code> is isolated
     * @param person_name the name of the person
     * @return <code>true</code> if the person is isolated
     *         <code>false</code> otherwise
     */
    boolean isIsolated(String person_name);

    /**
     * Isolates <code>person_name</code>
     * @param person_name the name of the person
     */
    void isolate(String person_name);

    /**
     * Sees if the community has that gossip
     * @param creator the creator of the gossip
     * @param target_names the people that are going to hear the gossip
     * @param description the description of the gossip
     * @return <code>true</code> if the community has that gossip
     *         <code>false</code> otherwise
     */
    boolean hasGossip(Person creator, Array<String> target_names, String description);

    /**
     * Returns a person that doesn't exist in the community
     * @param targetNames the names of the people
     * @return a person that doesn't exist in the community
     */
    String getNonExistentPerson(Array<String> targetNames);

    /**
     * Starts a gossip
     * @param gossip_creator_name the name of the person starting the gossip
     * @param targets the people that are hearing the gossip
     * @param gossip_description the gossip description
     */
    void startGossip(String gossip_creator_name, Array<String> targets, String gossip_description);

    /**
     * Iterator over a collection of Person
     * @param gossip_creator_name the name of the gossip creator
     * @param targets the people that are going to hear the gossip
     * @param gossip_description the gossip description
     * @return iterator of gossip targets
     */
    Iterator<Person> gossipTargets(String gossip_creator_name, Array<String> targets, String gossip_description);

    /**
     * Sees if there is gossip that is duplicated
     * @param gossip_creator_name the name of the creator of the gossip
     * @param target_names the people that are going to hear the gossip
     * @param gossip_description the gossip description
     * @return <code>true</code> if the same gossip is duplicated
     *         <code>false</code> otherwise
     */
    boolean hasDuplicateGossip(String gossip_creator_name, Array<String> target_names, String gossip_description);

    /**
     * Sees if a person has gossips to share
     * @param person_name the name of the person
     * @return <code>true</code> if the person has gossips to share
     *         <code>false</code> otherwise
     */
    boolean hasGossipsToShare(String person_name);

    /**
     * Returns the type of the person
     * @param person_name the name of the person
     * @return the type of the person
     */
    String getType(String person_name);

    /**
     * Sees if a sealed lips person is willing to share a gossip
     * @param person_name the name of the person
     * @return <code>true</code> if the person is willing to share
     *         <code>false</code> otherwise
     */
    boolean isWillingToShare(String person_name);

    /**
     * Shares a gossip within the community
     * @param person_name the person name that shares the gossip
     */
    void gossip(String person_name);

    /**
     * Iterator over a collection of Gossips
     * @param person_name the name of the person
     * @return iterator of the person gossips
     */
    Iterator<Gossip> personGossips(String person_name);

    /**
     * Checks if the person has secrets
     * @param person_name the person_name
     * @return <code>true</code> if the person has secrets
     *         <code>false</code> otherwise
     */
    boolean hasSecrets(String person_name);

    /**
     * Returns the people who are aware of the gossip
     * @param gossip the gossip
     * @return the people who are aware of the gossip
     */
    int peopleAwareOfGossip(Gossip gossip);

    /**
     * Iterator over a collection of Gossip
     * @param person_name the person name
     * @return iterator of gossips about the person
     */
    Iterator<Gossip> gossipsAbout(String person_name);

    /**
     * Sends the person to home
     * @param person_name the person name
     */
    void goHome(String person_name);

    /**
     * Iterator over a collection of Person
     * @return iterator of list of people
     */
    Iterator<Person> listPeople();

    /**
     * Registers a sealed person to the community
     * @param person_name the person name
     */
    void registSealedPerson(String person_name);

    /**
     * Registers a gossiper person to the community
     * @param person_name the person name
     */
    void registGossiperPerson(String person_name);

    /**
     * Registers a forgetful person to the community
     * @param person_name the person name
     */
    void registForgetfulPerson(String person_name, int gossip_capacity);

    /**
     * Checks if the community doesn't have landmarks
     * @return <code>true</code> if the community doesn't have landmarks
     *         <code>false</code> otherwise
     */
    boolean hasNoLandMarks();

    /**
     * Iterator over a collection of Landmark
     * @return iterator of list of landmarks
     */
    Iterator<Landmark> listLandmarks();

    /**
     * Registers a landmark
     * @param landmark_name the landmark name
     * @param landmark_capacity the landmark capacity
     */
    void registLandmark(String landmark_name, int landmark_capacity);

    /**
     * Iterator over a collection of Gossip
     * @param person_name the person name
     * @return iterator of gossips to share
     */
	Iterator<Gossip> gossipsToShare(String person_name);
}
