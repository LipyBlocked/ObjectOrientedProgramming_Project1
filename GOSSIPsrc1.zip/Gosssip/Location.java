package Gosssip;

public interface Location {
	/**
	 * Returns the name of the location
	 * @return the location of the location
	 */
	String getName();

}
