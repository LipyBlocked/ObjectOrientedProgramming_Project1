package Gosssip;

import dataStructures.*;

public class GroupClass implements Group {

    protected String firstUserName;
    private Array<Person> members;

    public GroupClass(Person firstMember) {
        members = new ArrayClass<Person>();
        members.insertLast(firstMember);
        firstUserName = members.get(0).getName();
    }

    public void addMember(Person member) {
        members.insertLast(member);
    }


    @Override
    public String getSingularMemberLocation() {
        return members.get(0).getCurrentLocation();
    }

    @Override
    public int getNumberOfMembers() {
        return members.size();
    }

    @Override
    public void removeMember(Person other_person) {
        members.removeAt(members.searchIndexOf(other_person));
    }

    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        Group other = (GroupClass) obj;
        if (firstUserName == null) {
            if (other.getFirstUserName() != null)
                return false;
        } else if (!firstUserName.equals(other.getFirstUserName()))
            return false;
        return true;
    }

    @Override
    public Iterator<Person> listGroupMembers() {
        return members.iterator();
    }


    @Override
    public String getFirstUserName() {
        return firstUserName;
    }

    @Override
    public boolean hasPerson(Person person) {
        return members.searchForward(person);
    }

    @Override
    public void shareGossip(String person_name) {
        getMember(person_name).shareGossip(members);
        ;
    }

    private Person getMember(String person_name) {
        return members.get(members.searchIndexOf(new PersonClass(person_name)));
    }


}
