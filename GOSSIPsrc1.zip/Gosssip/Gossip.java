package Gosssip;

import dataStructures.Iterator;

public interface Gossip {
	
	public void addTarget(Person target);
	
	String getGossipDescription();
	
	Iterator <Person>targets();
	
	Person getGossipCreator();

	public boolean hasTarget(String person_name);
	
	
	
	

}
