package Gosssip;

import dataStructures.*;

public class LandmarkClass extends AbstractLocation implements Landmark {

    private int capacity;
    private Array<Person> people;
    private Array<Group> groups;

    public LandmarkClass(String landmarkName, int landmarkSize) {
        super(landmarkName);
        capacity = landmarkSize;
        people = new ArrayClass<Person>();
        groups = new ArrayClass<Group>();
    }


    @Override
    public int getCurrentOccupation() {
        return people.size();
    }


    @Override
    public int getCapacity() {
        return capacity;
    }


    @Override
    public boolean isFull() {
        return people.size() == capacity;
    }


    @Override
    public void addPerson(Person person) {
        person.setLocation(name);
        people.insertLast(person);
        Group auxGroup = new GroupClass(person);
        groups.insertLast(auxGroup);
        deleteEmptyGroups();
    }


    public void deleteEmptyGroups() {
        int pos = -1;
        for (int i = 0; i < groups.size(); i++) {
            if (groups.get(i).getNumberOfMembers() == 0) {
                pos = i;
            }
        }
        if (pos != -1) {
            groups.removeAt(pos);
        }
    }


    @Override
    public void removePerson(Person person) {
        people.removeAt(people.searchIndexOf(person));
        getGroup(person).removeMember(person);
    }


    @Override
    public void joinGroup(Person person, Person other_person) {
        getGroup(person).removeMember(person);

        getGroup(other_person).addMember(person);
        deleteEmptyGroups();
    }


    private Group getGroup(Person person) {
        Group auxGroup = null;
        for (int i = 0; i < groups.size(); i++) {
            if (groups.get(i).hasPerson(person)) {
                return groups.get(i);
            }
        }
        return auxGroup;
    }

    private Person getPerson(String name) {
        Person auxPerson = new PersonClass(name);
        return people.get(people.searchIndexOf(auxPerson));
    }


    @Override
    public Iterator<Person> listGroupMembers(String person_name) {
        return getGroup(getPerson(person_name)).listGroupMembers();
    }


    @Override
    public boolean isEmpty() {
        return people.size() == 0;
    }


    @Override
    public Iterator<Group> LandmarkGroups() {
        return groups.iterator();
    }


    @Override
    public boolean areInSameGroup(String person_name, String other_person_name) {
        return getGroup(getPerson(other_person_name)).hasPerson(getPerson(person_name));
    }


    @Override
    public int getNrOfGroups() {
        return groups.size();
    }


    @Override
    public boolean isIsolated(String person_name) {
        return getGroup(getPerson(person_name)).getNumberOfMembers() == 1;
    }


    @Override
    public void isolate(String person_name) {
        groups.get(groups.searchIndexOf(getGroup(getPerson(person_name)))).removeMember(getPerson(person_name));
        ;
        ;
        groups.insertLast(new GroupClass(getPerson(person_name)));
    }


    @Override
    public void shareGossip(String person_name) {
        getGroup(getPerson(person_name)).shareGossip(person_name);
    }


}
