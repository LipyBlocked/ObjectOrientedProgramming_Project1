package Gosssip;

import dataStructures.*;

public abstract class AbstractPerson implements Person {

    /**
     * Constant that refers to the home
     */
    private static final String AT_HOME = "home";

    /**
     * Variable that is going store a name
     */
    protected String name;

    /**
     * Variable that is going store a location name
     */
    private String currentLocation;

    /**
     * Variable that is going to store the type of person
     */
    private String type;

    /**
     * Constructor that initializes the variables
     * @param name of the person
     * @param type of the person
     */
    public AbstractPerson(String name, String type) {
        this.name = name;
        this.type = type;
        currentLocation = AT_HOME;
    }

    /**
     * Returns the number of gossips of a person
     * @return the number of gossips of a person
     */
    public abstract int getNumberOfGossips();

    /**
     * Returns the current location of a person
     * @return the current location of a person
     */
    public String getCurrentLocation() {
        return currentLocation;
    }

    /**
     * Returns the name of the person
     * @return the name of the person
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the type of the person
     * @return the type of the person
     */
    public String getType() {
        return type;
    }

    /**
     * Returns an iterator over a collection of gossips
     * @return iterator of the gossips a person has
     */
    public abstract Iterator<Gossip> personGossips();


    /**
     * Sets a location with a <code>location_name</code>
     * @param location_name the name of the location
     */
    public void setLocation(String location_name) {
        currentLocation = location_name;
    }

    /**
     * Sees if a person has gossips to share
     * @return <code>true</code> if the person has gossips to share
     *         <code>false</code> otherwise
     */
    public abstract boolean hasGossipsToShare();

    /**
     * Adds a gossip to the person
     * @param g the gossip
     */
    public abstract void addGossip(Gossip g);

    /**
     * Sees if a person has this <code>gossip</code>
     * @param gossip the gossip
     * @return <code>true</code> if it has
     *         <code>false</code> otherwise
     */
    public abstract boolean hasGossip(Gossip gossip);

    /**
     * Shares a gossip with <code>members</code>
     * @param members the people that are going to hear the gossip
     */
    public abstract void shareGossip(Array<Person> members);

    /**
     * Compares <code>this</code> person to this <code>obj</code> person
     * @param obj the person being compared to the other
     * @return <code>true</code> if they're equal
     *         <code>false</code> otherwise
     */
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof AbstractPerson))
            return false;
        AbstractPerson other = (AbstractPerson) obj;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        return true;
    }

}
