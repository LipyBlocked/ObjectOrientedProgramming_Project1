package Gosssip;

import dataStructures.*;

public class GossipClass implements Gossip {
	
	private Person gossip_creator;
	private String description;
	private Array <Person> targets;

	public GossipClass(Person gossip_creator, Array <Person>targets,String description) {
		this.description = description;
		this.targets = targets;
		this.gossip_creator = gossip_creator;
	}

	@Override
	public void addTarget(Person target) {
		targets.insertLast(target);
	}

	@Override
	public String getGossipDescription() {
		return description;
	}

	@Override
	public Iterator <Person>targets() {
		return targets.iterator();
	}
	
	@Override
	public Person getGossipCreator() {
		return gossip_creator;
	}
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
		return false;
		Gossip other = (GossipClass) obj;
			if (description == null) {
		if (other.getGossipDescription() != null)
			return false;
		} else if (!description.equals(other.getGossipDescription()))
			return false;
		if (gossip_creator == null) {
			if (other.getGossipCreator() != null)
		return false;
		} else if (!gossip_creator.equals(other.getGossipCreator())) {
			return false;
	    } else if(haveSameTargets(other.targets()))
	    	return false;
		return true;
	}
	
	public boolean haveSameTargets(Iterator<Person> targets) {
		Iterator <Person>it = targets;
		while(it.hasNext()) {
			Person p = it.next();
			if(!this.targets.searchForward(p));{
				return false;
			}
		}
		return true ;
	}

	@Override
	public boolean hasTarget(String person_name) {
		return targets.searchForward(new PersonClass(person_name));
	}
	
	
	

}
