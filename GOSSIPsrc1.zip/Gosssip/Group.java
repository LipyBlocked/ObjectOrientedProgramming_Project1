package Gosssip;

import dataStructures.Iterator;

public interface Group {

    /**
     * Adds a <code>member</code> to a group
     * @param member the person that is going to be added
     */
    void addMember(Person member);

    /**
     * Returns the group of a singular person
     * @return returns the group of a singular person
     */
    String getSingularMemberLocation();

    /**
     * Returns the number of members of a group
     * @return the number of members of a group
     */
    int getNumberOfMembers();

    /**
     * Removes <code>other_person</code> from the group
     * @param other_person the person that is going to be removed
     */
    void removeMember(Person other_person);

    /**
     * Returns an iterator over a collection of Person objects that are members of a group
     * @return iterator of group members
     */
    Iterator<Person> listGroupMembers();

    /**
     * Returns the name of the first user of a group
     * @return the name of the first user of a group
     */
    String getFirstUserName();

    /**
     * Sees if a group has this <code>person</code>
     * @param person the person that is going to be checked
     * @return <code>true</code> if <code>person</code> is in the group
     *  	   <code>false</code> if it's not
     */
    boolean hasPerson(Person person);

    /**
     * Shares a gossip within a group
     * @param person_name the person that is sharing the gossips
     */
    void shareGossip(String person_name);


}
