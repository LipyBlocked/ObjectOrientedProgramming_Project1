package Gosssip;

import dataStructures.*;

public interface Person {

	/**
	 * Returns the number of gossips a person knows
	 * @return the number of gossips a person knows
	 */
	int getNumberOfGossips();

	/**
	 * Returns the current location of a person
	 * @return returns the current location of a person
	 */
	String getCurrentLocation();

	/**
	 * Returns the name of a person
	 * @return returns the name of a person
	 */
	String getName();

	/**
	 * Sets a location with name <code>location_name</code>
	 * @param location_name the name of the location
	 */
	void setLocation(String location_name);

	/**
	 * Sees if a person has gossips to share
	 * @return <code>true</code> if the person has gossips to share
	 * 		   <code>false</code> otherwise
	 */
	boolean hasGossipsToShare();

	/**
	 * Returns the type of the person
	 * @return the type of the person
	 */
	String getType();

	/**
	 * A collection over Gossips objects
	 * @return iterator of gossips that a person has
	 */
	Iterator <Gossip> personGossips();

	/**
	 * Adds a gossip to the community
	 * @param g the gossip
	 */
	void addGossip(Gossip g);

	/**
	 * Sees if a person has a certain gossip
	 * @param gossip the gossip
	 * @return <code>true</code> if the person has the gossip
	 * 		   <code>false</code> otherwise
	 */
	boolean hasGossip(Gossip gossip);

	/**
	 * Shares a gossip with some members of the group
	 * @param members the people that are going to hear the gossip
	 */
	void shareGossip(Array <Person> members);

	Iterator<Gossip> gossipsToShare();

	
	

}
