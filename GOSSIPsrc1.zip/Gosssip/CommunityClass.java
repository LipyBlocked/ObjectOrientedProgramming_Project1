package Gosssip;

import dataStructures.*;


public class CommunityClass implements Community {

    public static final String HOME = "home";
    private static final String FORGETFUL = "forgetful";
    private static final String GOSSIPER = "gossiper";
    private static final String SEALED = "sealed";

    private Array<Landmark> landmarks;
    private Array<Person> people;
    private Array<Gossip> gossips;

    public CommunityClass() {
        landmarks = new ArrayClass<Landmark>();
        people = new ArrayClass<Person>();
        gossips = new ArrayClass<Gossip>();

    }

    @Override
    public boolean hasLandMark(String landmark_name, int landmark_size) {
        Landmark auxLandmark = new LandmarkClass(landmark_name, landmark_size);
        return landmarks.searchForward(auxLandmark);
    }

    @Override
    public Iterator<Landmark> landmarks() {
        return landmarks.iterator();
    }

    @Override
    public Iterator<Person> people() {
        return people.iterator();
    }


    @Override
    public boolean hasNoPerson() {
        return people.size() == 0;

    }

    @Override
    public boolean hasPerson(String name) {
        Person auxPerson = new PersonClass(name);
        return people.searchForward(auxPerson);
    }

    @Override
    public void registlandmark(String landmark_name, int landmark_capacity) {
        Landmark auxLandmark = new LandmarkClass(landmark_name, landmark_capacity);
        landmarks.insertLast(auxLandmark);
    }

    @Override
    public void addForgetfulPerson(String person_name, int gossip_capacity) {
        Person auxForgetful = new ForgetfulClass(person_name, gossip_capacity);
        people.insertLast(auxForgetful);
    }

    @Override
    public void addGossiperPerson(String person_name) {
        Person auxGossiper = new GossiperClass(person_name);
        people.insertLast(auxGossiper);
    }

    @Override
    public void addSealedPerson(String person_name) {
        Person auxSealed = new SealedLipsClass(person_name);
        people.insertLast(auxSealed);
    }

    @Override
    public String getPersonLocation(String person_name) {
        Person auxPerson = new PersonClass(person_name);
        return people.get(people.searchIndexOf(auxPerson)).getCurrentLocation();
    }

    @Override
    public boolean landmarkIsFull(String destination) {
        Landmark auxLandamrk = new LandmarkClass(destination, 0);
        return landmarks.get(landmarks.searchIndexOf(auxLandamrk)).isFull();
    }

    @Override
    public void goTo(String person_name, String destination) {
        Person auxPerson = new PersonClass(person_name);
        Landmark auxLandamrk = new LandmarkClass(destination, 0);
        if (getPerson(person_name).getCurrentLocation().equals(HOME)) {
            landmarks.get(landmarks.searchIndexOf(auxLandamrk)).addPerson(people.get(people.searchIndexOf(auxPerson)));
        } else {
            Landmark currentLandmarkName = getLandmark(getPerson(person_name).getCurrentLocation());
            landmarks.get(landmarks.searchIndexOf(currentLandmarkName)).removePerson(people.get(people.searchIndexOf(auxPerson)));
            landmarks.get(landmarks.searchIndexOf(auxLandamrk)).addPerson(people.get(people.searchIndexOf(auxPerson)));
            landmarks.get(landmarks.searchIndexOf(auxLandamrk)).deleteEmptyGroups();
        }

    }

    @Override
    public void joinGroup(String person_name, String other_person_name) {
        String landmark_name = getPerson(person_name).getCurrentLocation();
        landmarks.get(landmarks.searchIndexOf(getLandmark(landmark_name))).joinGroup(getPerson(person_name), getPerson(other_person_name));
    }

    private Person getPerson(String person_name) {
        Person auxPerson = new PersonClass(person_name);
        return people.get(people.searchIndexOf(auxPerson));
    }

    private Landmark getLandmark(String landmark_name) {
        Landmark auxLandmark = new LandmarkClass(landmark_name, 0);
        return landmarks.get(landmarks.searchIndexOf(auxLandmark));
    }


    @Override
    public Iterator<Person> personGroupMembers(String person_name) {
        String auxLandmarkName = getPerson(person_name).getCurrentLocation();
        return getLandmark(auxLandmarkName).listGroupMembers(person_name);
    }

    @Override
    public boolean landmarkIsEmpty(String landmark_name) {
        return getLandmark(landmark_name).isEmpty();
    }

    @Override
    public int getLandmarkCapacity(String landmark_name) {
        return getLandmark(landmark_name).getCurrentOccupation();
    }

    @Override
    public Iterator<Group> groups(String landmark_name) {
        return getLandmark(landmark_name).LandmarkGroups();
    }

    @Override
    public boolean areInSameGroup(String person_name, String other_person_name) {
        String landmark_name = (getPerson(other_person_name).getCurrentLocation());
        return getLandmark(landmark_name).areInSameGroup(person_name, other_person_name);
    }

    @Override
    public int getNrOfGroups(String landmark_name) {
        return getLandmark(landmark_name).getNrOfGroups();
    }

    @Override
    public boolean isIsolated(String person_name) {
        String landmark_name = getPerson(person_name).getCurrentLocation();
        return getLandmark(landmark_name).isIsolated(person_name);
    }

    @Override
    public void isolate(String person_name) {
        String landmark_name = getPerson(person_name).getCurrentLocation();
        getLandmark(landmark_name).isolate(person_name);
    }

    @Override
    public boolean hasGossip(Person creator, Array<String> target_names, String description) {
        return gossips.searchForward(gossips.get(gossips.searchIndexOf(getGossip(creator, target_names, description))));
    }

    private Array<Person> getNameToPersonArray(Array<String> target_names) {
        Array<Person> targets = new ArrayClass<Person>();
        for (int i = 0; i < target_names.size(); i++) {
            targets.insertLast(getPerson(target_names.get(i)));
        }
        return targets;
    }

    @Override
    public void startGossip(String gossip_creator_name, Array<String> target_names, String gossip_description) {
        Gossip auxGossip = new GossipClass(getPerson(gossip_creator_name), getNameToPersonArray(target_names), gossip_description);
        gossips.insertLast(auxGossip);
        getPerson(gossip_creator_name).addGossip(auxGossip);
    }


    private Gossip getGossip(Person creator, Array<String> target_names, String gossip_description) {
        Gossip auxGossip = new GossipClass(creator, getNameToPersonArray(target_names), gossip_description);
        return gossips.get(gossips.searchIndexOf(auxGossip));
    }


    @Override
    public String getNonExistentPerson(Array<String> targetNames) {
        int i = 0;
        boolean found = false;
        String non_existent_person = null;
        while (i < targetNames.size() && !found) {
            if (!hasPerson(targetNames.get(i))) {
                non_existent_person = targetNames.get(i);
                found = true;
            }
            i++;
        }

        return non_existent_person;
    }


    @Override
    public Iterator<Person> gossipTargets(String gossip_creator_name, Array<String> targets, String gossip_description) {
        return getGossip(getPerson(gossip_creator_name), targets, gossip_description).targets();
    }

    @Override
    public boolean hasDuplicateGossip(String gossip_creator_name, Array<String> target_names, String gossip_description) {
        return gossips.searchForward(new GossipClass(getPerson(gossip_creator_name), getNameToPersonArray(target_names), gossip_description));
    }

    @Override
    public boolean hasGossipsToShare(String person_name) {
        return getPerson(person_name).hasGossipsToShare();
    }

    @Override
    public String getType(String person_name) {
        return getPerson(person_name).getType();
    }

    @Override
    public boolean isWillingToShare(String person_name) {
        if (!getPerson(person_name).getType().equals(SEALED)) return true;
        return ((SealedLipsClass) getPerson(person_name)).isWillingToShare();
    }

    @Override
    public void gossip(String person_name) {
        getLandmark(getPerson(person_name).getCurrentLocation()).shareGossip(person_name);
    }

    @Override
    public Iterator<Gossip> personGossips(String person_name) {
        return getPerson(person_name).personGossips();
    }

    @Override
    public boolean hasSecrets(String person_name) {
        int i = 0;
        while (i < gossips.size()) {
            Iterator<Person> it = gossips.get(i).targets();
            while (it.hasNext()) {
                Person p = it.next();
                if (getPerson(person_name).equals(p)) {
                    return true;
                }
            }
            i++;
        }

        return false;
    }

    @Override
    public int peopleAwareOfGossip(Gossip gossip) {
        int nr_of_people = 0;
        for (int i = 0; i < people.size(); i++) {
            if (people.get(i).hasGossip(gossip)) {
                nr_of_people++;
            }
        }
        return nr_of_people;
    }

    @Override
    public Iterator<Gossip> gossipsAbout(String person_name) {
        deleteForgottenGossips();
        Array<Gossip> gossipsAboutPerson = new ArrayClass<Gossip>();
        for (int i = 0; i < gossips.size(); i++) {
            if (gossips.get(i).hasTarget(person_name)) {
                gossipsAboutPerson.insertLast(gossips.get(i));
            }
        }

        return gossipsAboutPerson.iterator();
    }

    private void deleteForgottenGossips() {
        Array<Gossip> auxGossips = new ArrayClass<Gossip>();
        for (int i = 0; i < gossips.size(); i++) {
            if (!(peopleAwareOfGossip(gossips.get(i)) == 0)) {
                auxGossips.insertLast(gossips.get(i));
            }
        }
        gossips = auxGossips;
    }

    @Override
    public void goHome(String person_name) {
        if (!getPerson(person_name).getCurrentLocation().equals(HOME)) {
            getLandmark(getPerson(person_name).getCurrentLocation()).removePerson(getPerson(person_name));
            getPerson(person_name).setLocation(HOME);
        }
    }

    @Override
    public Iterator<Person> listPeople() {
        return people.iterator();
    }

    @Override
    public void registSealedPerson(String person_name) {
        people.insertLast(new SealedLipsClass(person_name));;;
    }

    @Override
    public void registGossiperPerson(String person_name) {
        people.insertLast(new GossiperClass(person_name));;
    }

    @Override
    public void registForgetfulPerson(String person_name, int gossip_capacity) {
        people.insertLast(new ForgetfulClass(person_name,gossip_capacity));
    }

    @Override
    public boolean hasNoLandMarks() {
        return landmarks.size()==0;
    }

    @Override
    public Iterator<Landmark> listLandmarks() {
        return landmarks.iterator();
    }

    @Override
    public void registLandmark(String landmark_name, int landmark_capacity) {
        landmarks.insertLast(new LandmarkClass(landmark_name,landmark_capacity));;
    }

	@Override
	public Iterator<Gossip> gossipsToShare(String person_name) {
		return getPerson(person_name).gossipsToShare();
	}


}
