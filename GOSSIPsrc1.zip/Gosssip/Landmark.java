package Gosssip;

import dataStructures.Iterator;

public interface Landmark extends Location {

	/**
	 * Returns the capacity of the group
	 * @return the capacity of the group
	 */
	int getCapacity();

	/**
	 * Returns the current position of a person
	 * @return the current position of a person
	 */
	int getCurrentOccupation();

	/**
	 * Verifies if the current group is full
	 * @return <code>true</code> if the group is full
	 * 		   <code>false</code> group is not full
	 */
	boolean isFull();

	/**
	 * Adds a person to a landmark
	 * @param person that is going to be added to the landmark
	 */
	void addPerson(Person person);

	/**
	 * Deletes an empty group
	 */
	void deleteEmptyGroups();

	/**
	 * Removes the <code>person</code> from the landmark
	 * @param person that is going to be removed
	 */
	void removePerson(Person person);

	/**
	 * Joins <code>other_person</code> to the group of <code>person</code>
	 * @param person the one that is already in the group
	 * @param other_person that is going to be joined
	 */
	void joinGroup(Person person, Person other_person);

	/**
	 * Returns an iterator over a collection of Person objects that are members of a group
	 * @param person_name the name of a person that is in the group
	 * @return iterator of the group members
	 */
	Iterator<Person> listGroupMembers(String person_name);

	/**
	 * Sees if the landmark doesn't have groups
	 * @return <code>true</code> if the landmark is empty
	 * 		   <code>false</code> if it's not
	 */
	boolean isEmpty();

	/**
	 * Returns an iterator over a collection of Groups objects, the groups of a landmark
	 * @return iterator of groups of a landmark
	 */
	Iterator<Group> LandmarkGroups();

	/**
	 * Sees if <code>person_name</code> and <code>other_person_name</code> are in the same group
	 * @param person_name the first person
	 * @param other_person_name the second person
	 * @return <code>true</code> if <code>person_name</code> and <code>other_person_name</code> are in the same group
	 *  	  <code>false</code> otherwise
	 */
	boolean areInSameGroup(String person_name, String other_person_name);

	/**
	 * Returns the number of groups in a landmark
	 * @return the number of groups in a landmark
	 */
	int getNrOfGroups();

	/**
	 * Sees if <code>person_name</code> is isolated
	 * @param person_name the person that is going to be isolated
	 * @return <code>true</code> if <code>person_name</code> is isolated
	 * 			<code>false</code> if it's not
	 */
	boolean isIsolated(String person_name);

	/**
	 * Isolates <code>person_name</code> from other people
	 * @param person_name the one that is going to be isolated
	 */
	void isolate(String person_name);

	/**
	 * Shares a gossip to the group
	 * @param person_name the person that is sharing the gossip
	 */
	void shareGossip(String person_name);

}
