package Gosssip;

public interface Forgetful extends Person {

}
