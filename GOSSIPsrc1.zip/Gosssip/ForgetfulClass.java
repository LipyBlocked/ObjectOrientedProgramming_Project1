package Gosssip;

import dataStructures.Array;
import dataStructures.ArrayClass;
import dataStructures.Iterator;

public class ForgetfulClass extends AbstractPerson implements Forgetful {

    private static final String TYPE = "forgetful";


    private Array<Gossip> gossips;
    private Array<Gossip> gossipsToShare;
    private int gossipCapacity;

    public ForgetfulClass(String name, int gossipCapacity) {
        super(name, TYPE);
        this.gossipCapacity = gossipCapacity;
        gossips = new ArrayClass<Gossip>(gossipCapacity);
        gossipsToShare = new ArrayClass<Gossip>(1);

    }

    public int GetGossipCapacity() {
        return gossipCapacity;
    }

    public void addGossip(Gossip gossip) {
        if (!gossips.searchForward(gossip)) {
            if (gossips.size() == gossipCapacity) {
                gossips.removeAt(0);
                gossips.insertLast(gossip);
            } else {
                gossips.insertLast(gossip);
            }
        }
    }

    @Override
    public int getNumberOfGossips() {
        return gossips.size();
    }

    @Override
    public Iterator<Gossip> personGossips() {
        return gossips.iterator();
    }

    @Override
    public boolean hasGossipsToShare() {
        return gossips.size() > 0;
    }

    @Override
    public boolean hasGossip(Gossip gossip) {
        return gossips.searchForward(gossip);
    }

    @Override
	public void shareGossip(Array<Person> members) {
		Array<Gossip> auxGossips = new ArrayClass<Gossip>();
		int i=0; 
		auxGossips.insertLast(gossips.get(i));
		gossips.insertLast(gossips.get(i));
		gossips.removeAt(0);
		gossipsToShare = auxGossips;
		
		for(int m=0;m<members.size();m++) {
			members.get(m).addGossip(gossipsToShare.get(0));
		}
	}

	@Override
	public Iterator<Gossip> gossipsToShare() {
		return gossipsToShare.iterator();
	}

}
